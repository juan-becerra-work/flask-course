MAIL_USERNAME = 'buildasaasappwithflask@gmail.com'
MAIL_PASSWORD = 'helicopterpantswalrusfoot'

STRIPE_SECRET_KEY = 'sk_test_nycOOQdO9C16zxubr2WWtbug'
STRIPE_PUBLISHABLE_KEY = 'pk_test_ClU5mzNj1YxRRnrdZB5jEO29'
